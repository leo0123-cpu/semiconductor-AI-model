
"""
대회용 AI 밴드갭 예측 프로그램
Competition Version: Bandgap Prediction for Next-Generation Power Semiconductors

핵심 기능
1. 화학식(formula)을 원소 특징(feature)으로 변환
2. 3개 회귀 모델 학습
   - Ridge Regression
   - Random Forest Regressor
   - Gradient Boosting Regressor
3. K-Fold 교차검증으로 모델 성능 비교
4. RandomizedSearchCV로 하이퍼파라미터 튜닝
5. 최종 모델 선택: 교차검증 MAE가 가장 낮은 모델
6. 사용자가 입력한 화학식에 대해 3개 모델의 예측값, 평균값, 모델 간 불확실성 출력
7. 전력 반도체 후보 적합 점수 계산
8. 후보 물질 여러 개를 한 번에 평가하여 순위표 CSV 저장
9. 최종 모델의 특징 중요도(permutation importance) CSV 저장

필요 라이브러리
pip install pandas numpy scikit-learn joblib

실행
python bandgap_competition.py

CSV 데이터셋을 직접 쓸 경우 같은 폴더에 bandgap_dataset.csv 파일을 만든다.
필수 컬럼 예시:
formula,band_gap
GaN,3.4
SiC,3.2
ZnO,3.3

참고:
- 데모 데이터는 코드 실행 확인용이다.
- 실제 대회 제출용은 Matminer, Materials Project, 논문 표 등에서 얻은 실제 데이터로 CSV를 구성하는 것이 좋다.
- 이 코드는 결정 구조 정보 없이 화학식 기반 특징만 사용하는 버전이다.
"""

import argparse
import os
import re
import math
import warnings
import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, RandomizedSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")


# =========================================================
# 1. 원소 기본 데이터
# =========================================================
# Z: 원자번호
# period: 주기
# group: 족
# en: 전기음성도
# radius: 원자 반지름(pm)
# mass: 원자량
# valence: 간단한 원자가전자 수 추정
ELEMENTS = {
    "H":  {"Z": 1,  "period": 1, "group": 1,  "en": 2.20, "radius": 53,  "mass": 1.008,   "valence": 1},
    "B":  {"Z": 5,  "period": 2, "group": 13, "en": 2.04, "radius": 87,  "mass": 10.81,   "valence": 3},
    "C":  {"Z": 6,  "period": 2, "group": 14, "en": 2.55, "radius": 67,  "mass": 12.011,  "valence": 4},
    "N":  {"Z": 7,  "period": 2, "group": 15, "en": 3.04, "radius": 56,  "mass": 14.007,  "valence": 5},
    "O":  {"Z": 8,  "period": 2, "group": 16, "en": 3.44, "radius": 48,  "mass": 15.999,  "valence": 6},
    "F":  {"Z": 9,  "period": 2, "group": 17, "en": 3.98, "radius": 42,  "mass": 18.998,  "valence": 7},

    "Na": {"Z": 11, "period": 3, "group": 1,  "en": 0.93, "radius": 190, "mass": 22.990,  "valence": 1},
    "Mg": {"Z": 12, "period": 3, "group": 2,  "en": 1.31, "radius": 145, "mass": 24.305,  "valence": 2},
    "Al": {"Z": 13, "period": 3, "group": 13, "en": 1.61, "radius": 118, "mass": 26.982,  "valence": 3},
    "Si": {"Z": 14, "period": 3, "group": 14, "en": 1.90, "radius": 111, "mass": 28.085,  "valence": 4},
    "P":  {"Z": 15, "period": 3, "group": 15, "en": 2.19, "radius": 98,  "mass": 30.974,  "valence": 5},
    "S":  {"Z": 16, "period": 3, "group": 16, "en": 2.58, "radius": 88,  "mass": 32.06,   "valence": 6},
    "Cl": {"Z": 17, "period": 3, "group": 17, "en": 3.16, "radius": 79,  "mass": 35.45,   "valence": 7},

    "K":  {"Z": 19, "period": 4, "group": 1,  "en": 0.82, "radius": 243, "mass": 39.098,  "valence": 1},
    "Ca": {"Z": 20, "period": 4, "group": 2,  "en": 1.00, "radius": 194, "mass": 40.078,  "valence": 2},
    "Sc": {"Z": 21, "period": 4, "group": 3,  "en": 1.36, "radius": 184, "mass": 44.956,  "valence": 3},
    "Ti": {"Z": 22, "period": 4, "group": 4,  "en": 1.54, "radius": 176, "mass": 47.867,  "valence": 4},
    "V":  {"Z": 23, "period": 4, "group": 5,  "en": 1.63, "radius": 171, "mass": 50.942,  "valence": 5},
    "Cr": {"Z": 24, "period": 4, "group": 6,  "en": 1.66, "radius": 166, "mass": 51.996,  "valence": 6},
    "Mn": {"Z": 25, "period": 4, "group": 7,  "en": 1.55, "radius": 161, "mass": 54.938,  "valence": 7},
    "Fe": {"Z": 26, "period": 4, "group": 8,  "en": 1.83, "radius": 156, "mass": 55.845,  "valence": 8},
    "Co": {"Z": 27, "period": 4, "group": 9,  "en": 1.88, "radius": 152, "mass": 58.933,  "valence": 9},
    "Ni": {"Z": 28, "period": 4, "group": 10, "en": 1.91, "radius": 149, "mass": 58.693,  "valence": 10},
    "Cu": {"Z": 29, "period": 4, "group": 11, "en": 1.90, "radius": 145, "mass": 63.546,  "valence": 11},
    "Zn": {"Z": 30, "period": 4, "group": 12, "en": 1.65, "radius": 142, "mass": 65.38,   "valence": 12},
    "Ga": {"Z": 31, "period": 4, "group": 13, "en": 1.81, "radius": 136, "mass": 69.723,  "valence": 3},
    "Ge": {"Z": 32, "period": 4, "group": 14, "en": 2.01, "radius": 125, "mass": 72.630,  "valence": 4},
    "As": {"Z": 33, "period": 4, "group": 15, "en": 2.18, "radius": 114, "mass": 74.922,  "valence": 5},
    "Se": {"Z": 34, "period": 4, "group": 16, "en": 2.55, "radius": 103, "mass": 78.971,  "valence": 6},
    "Br": {"Z": 35, "period": 4, "group": 17, "en": 2.96, "radius": 94,  "mass": 79.904,  "valence": 7},

    "Sr": {"Z": 38, "period": 5, "group": 2,  "en": 0.95, "radius": 219, "mass": 87.62,   "valence": 2},
    "Y":  {"Z": 39, "period": 5, "group": 3,  "en": 1.22, "radius": 212, "mass": 88.906,  "valence": 3},
    "Zr": {"Z": 40, "period": 5, "group": 4,  "en": 1.33, "radius": 206, "mass": 91.224,  "valence": 4},
    "Nb": {"Z": 41, "period": 5, "group": 5,  "en": 1.60, "radius": 198, "mass": 92.906,  "valence": 5},
    "Mo": {"Z": 42, "period": 5, "group": 6,  "en": 2.16, "radius": 190, "mass": 95.95,   "valence": 6},
    "Ag": {"Z": 47, "period": 5, "group": 11, "en": 1.93, "radius": 165, "mass": 107.868, "valence": 11},
    "Cd": {"Z": 48, "period": 5, "group": 12, "en": 1.69, "radius": 161, "mass": 112.414, "valence": 12},
    "In": {"Z": 49, "period": 5, "group": 13, "en": 1.78, "radius": 156, "mass": 114.818, "valence": 3},
    "Sn": {"Z": 50, "period": 5, "group": 14, "en": 1.96, "radius": 145, "mass": 118.710, "valence": 4},
    "Sb": {"Z": 51, "period": 5, "group": 15, "en": 2.05, "radius": 133, "mass": 121.760, "valence": 5},
    "Te": {"Z": 52, "period": 5, "group": 16, "en": 2.10, "radius": 123, "mass": 127.60,  "valence": 6},
    "I":  {"Z": 53, "period": 5, "group": 17, "en": 2.66, "radius": 115, "mass": 126.904, "valence": 7},

    "Ba": {"Z": 56, "period": 6, "group": 2,  "en": 0.89, "radius": 253, "mass": 137.327, "valence": 2},
    "La": {"Z": 57, "period": 6, "group": 3,  "en": 1.10, "radius": 195, "mass": 138.905, "valence": 3},
    "Hf": {"Z": 72, "period": 6, "group": 4,  "en": 1.30, "radius": 208, "mass": 178.49,  "valence": 4},
    "Ta": {"Z": 73, "period": 6, "group": 5,  "en": 1.50, "radius": 200, "mass": 180.948, "valence": 5},
    "W":  {"Z": 74, "period": 6, "group": 6,  "en": 2.36, "radius": 193, "mass": 183.84,  "valence": 6},
    "Pb": {"Z": 82, "period": 6, "group": 14, "en": 2.33, "radius": 154, "mass": 207.2,   "valence": 4},
    "Bi": {"Z": 83, "period": 6, "group": 15, "en": 2.02, "radius": 143, "mass": 208.980, "valence": 5},
}

PROPERTY_KEYS = ["Z", "period", "group", "en", "radius", "mass", "valence"]


# =========================================================
# 2. 화학식 파싱 및 특징 생성
# =========================================================
def parse_formula(formula: str) -> dict:
    """
    단순 화학식 파서
    지원 예시: GaN, SiC, Al2O3, Ga2O3, BaTiO3
    미지원 예시: Ca(OH)2 같은 괄호 포함 화학식
    """
    formula = str(formula).strip()

    if not formula:
        raise ValueError("화학식이 비어 있습니다.")

    if "(" in formula or ")" in formula:
        raise ValueError("괄호가 들어간 화학식은 현재 버전에서 지원하지 않습니다.")

    pattern = r"([A-Z][a-z]?)(\d*\.?\d*)"
    matches = re.findall(pattern, formula)

    if not matches:
        raise ValueError(f"화학식을 읽을 수 없습니다: {formula}")

    parsed_text = "".join(element + number for element, number in matches)
    if parsed_text != formula:
        raise ValueError(f"화학식 형식이 올바르지 않습니다: {formula}")

    counts = {}
    for element, number in matches:
        if element not in ELEMENTS:
            raise ValueError(f"지원하지 않는 원소입니다: {element}")

        amount = float(number) if number else 1.0
        if amount <= 0:
            raise ValueError("원소 개수는 0보다 커야 합니다.")

        counts[element] = counts.get(element, 0.0) + amount

    return counts


def weighted_std(values, weights):
    average = np.average(values, weights=weights)
    variance = np.average((values - average) ** 2, weights=weights)
    return math.sqrt(variance)


def formula_to_features(formula: str) -> dict:
    counts = parse_formula(formula)
    total_atoms = sum(counts.values())
    fractions = {element: count / total_atoms for element, count in counts.items()}

    features = {
        "num_elements": len(counts),
        "total_atoms": total_atoms,
        "composition_entropy": -sum(frac * math.log(frac) for frac in fractions.values()),
    }

    for key in PROPERTY_KEYS:
        values = np.array([ELEMENTS[element][key] for element in counts.keys()], dtype=float)
        weights = np.array([fractions[element] for element in counts.keys()], dtype=float)

        features[f"{key}_mean"] = float(np.average(values, weights=weights))
        features[f"{key}_min"] = float(np.min(values))
        features[f"{key}_max"] = float(np.max(values))
        features[f"{key}_range"] = float(np.max(values) - np.min(values))
        features[f"{key}_std"] = float(weighted_std(values, weights))

    # 반도체에서 자주 의미 있게 볼 수 있는 조합 특징
    features["en_range_x_radius_range"] = features["en_range"] * features["radius_range"]
    features["mean_Z_over_mean_radius"] = features["Z_mean"] / (features["radius_mean"] + 1e-9)
    features["mean_en_over_mean_radius"] = features["en_mean"] / (features["radius_mean"] + 1e-9)
    features["valence_per_atom"] = features["valence_mean"]

    return features


def make_feature_table(formulas):
    return pd.DataFrame([formula_to_features(formula) for formula in formulas])


# =========================================================
# 3. 데이터 불러오기
# =========================================================
def normalize_columns(df):
    """
    여러 데이터셋의 컬럼명을 최대한 자동으로 맞춘다.
    """
    rename_map = {}

    formula_candidates = ["formula", "composition", "pretty_formula", "formula_pretty", "full_formula"]
    bandgap_candidates = ["band_gap", "bandgap", "gap", "gap pbe", "e_gap", "Eg", "eg"]

    lower_columns = {str(col).lower(): col for col in df.columns}

    for candidate in formula_candidates:
        if candidate.lower() in lower_columns:
            rename_map[lower_columns[candidate.lower()]] = "formula"
            break

    for candidate in bandgap_candidates:
        if candidate.lower() in lower_columns:
            rename_map[lower_columns[candidate.lower()]] = "band_gap"
            break

    df = df.rename(columns=rename_map)
    return df


def load_data(csv_path="bandgap_dataset.csv"):
    if os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
        df = normalize_columns(df)
        print(f"CSV 데이터셋을 불러왔습니다: {csv_path}")
    else:
        print("bandgap_dataset.csv 파일이 없어 데모 데이터를 사용합니다.")
        print("데모 데이터는 실행 확인용입니다. 대회 제출은 실제 데이터셋 사용을 권장합니다.\n")

        demo_data = {
            "formula": [
                "Si", "Ge", "C", "BN", "GaN", "SiC", "AlN", "ZnO", "GaAs", "InP",
                "CdTe", "TiO2", "SnO2", "BaTiO3", "SrTiO3", "Al2O3", "HfO2", "ZrO2",
                "PbTe", "InN", "GaP", "AlP", "ZnS", "ZnSe", "Ga2O3", "MgO", "CaO",
                "BaO", "SnS", "SnSe", "In2O3", "WO3", "MoS2", "Bi2Te3", "Ta2O5",
                "Nb2O5", "La2O3", "Mg2Si", "FeS2", "Cu2O", "Ag2S"
            ],
            # 여러 문헌/상식적 값을 참고한 테스트용 근사값이다.
            # 실제 보고서에는 반드시 데이터 출처를 따로 정리해야 한다.
            "band_gap": [
                1.12, 0.66, 5.50, 6.00, 3.40, 3.20, 6.20, 3.30, 1.42, 1.34,
                1.50, 3.20, 3.60, 3.20, 3.25, 8.80, 5.70, 5.00,
                0.30, 0.70, 2.26, 2.45, 3.60, 2.70, 4.80, 7.80, 7.10,
                4.00, 1.30, 0.90, 2.90, 2.70, 1.80, 0.15, 4.00,
                3.40, 5.50, 0.77, 0.95, 2.10, 1.00
            ]
        }
        df = pd.DataFrame(demo_data)

    if "formula" not in df.columns or "band_gap" not in df.columns:
        raise ValueError("CSV에는 formula, band_gap 컬럼이 필요합니다.")

    df = df[["formula", "band_gap"]].dropna()
    df["formula"] = df["formula"].astype(str)
    df["band_gap"] = pd.to_numeric(df["band_gap"], errors="coerce")
    df = df.dropna()

    valid_rows = []
    for _, row in df.iterrows():
        try:
            parse_formula(row["formula"])
            valid_rows.append(row)
        except ValueError as error:
            print(f"제외된 데이터: {row['formula']} / 이유: {error}")

    clean_df = pd.DataFrame(valid_rows).reset_index(drop=True)

    if len(clean_df) < 20:
        raise ValueError("사용 가능한 데이터가 너무 적습니다. 대회용으로는 최소 50개 이상, 가능하면 수백 개 이상을 권장합니다.")

    return clean_df


# =========================================================
# 4. 모델 구성 및 하이퍼파라미터 튜닝
# =========================================================
def get_model_spaces():
    """
    3개 모델과 탐색할 하이퍼파라미터 범위
    """
    model_spaces = {
        "Ridge Regression": {
            "estimator": Pipeline([
                ("scaler", StandardScaler()),
                ("model", Ridge())
            ]),
            "params": {
                "model__alpha": [0.01, 0.1, 1.0, 10.0, 100.0]
            }
        },
        "Random Forest": {
            "estimator": RandomForestRegressor(random_state=42),
            "params": {
                "n_estimators": [80, 150, 250],
                "max_depth": [None, 4, 8, 12],
                "min_samples_leaf": [1, 2, 4],
                "max_features": ["sqrt", 0.7, 1.0]
            }
        },
        "Gradient Boosting": {
            "estimator": GradientBoostingRegressor(random_state=42),
            "params": {
                "n_estimators": [80, 150, 250],
                "learning_rate": [0.01, 0.03, 0.05, 0.1],
                "max_depth": [2, 3, 4],
                "subsample": [0.7, 0.9, 1.0]
            }
        }
    }

    return model_spaces


def tune_and_compare_models(X, y, cv_splits=5, n_iter=20):
    """
    RandomizedSearchCV로 3개 모델을 튜닝하고 교차검증 MAE 기준으로 비교한다.
    """
    cv = KFold(n_splits=cv_splits, shuffle=True, random_state=42)
    model_spaces = get_model_spaces()

    trained_models = {}
    rows = []

    print("\n모델 튜닝 및 교차검증 시작")
    print("-" * 80)

    for model_name, space in model_spaces.items():
        search = RandomizedSearchCV(
            estimator=space["estimator"],
            param_distributions=space["params"],
            n_iter=n_iter,
            scoring="neg_mean_absolute_error",
            cv=cv,
            random_state=42,
            n_jobs=1,
            refit=True
        )

        search.fit(X, y)

        best_model = search.best_estimator_
        best_mae = -search.best_score_

        # 선택된 모델의 전체 데이터 기준 R2도 참고용으로 계산
        pred_all = best_model.predict(X)
        r2_all = r2_score(y, pred_all)

        trained_models[model_name] = best_model

        rows.append({
            "model_name": model_name,
            "cv_mae": best_mae,
            "r2_on_all_data_reference": r2_all,
            "best_params": search.best_params_
        })

        print(f"{model_name:20s} | CV MAE: {best_mae:.4f} eV | 참고 R2: {r2_all:.4f}")
        print(f"  최적 파라미터: {search.best_params_}")

    results_df = pd.DataFrame(rows).sort_values(by="cv_mae").reset_index(drop=True)
    best_model_name = results_df.iloc[0]["model_name"]

    print("-" * 80)
    print(f"최종 선택 모델: {best_model_name}")
    print("선택 기준: K-Fold 교차검증 CV MAE가 가장 낮은 모델")
    print()

    return trained_models, results_df, best_model_name


# =========================================================
# 5. 특징 중요도 분석
# =========================================================
def analyze_feature_importance(model, X, y, output_path="feature_importance.csv"):
    """
    최종 모델의 특징 중요도를 permutation importance로 계산한다.
    """
    result = permutation_importance(
        model,
        X,
        y,
        n_repeats=10,
        random_state=42,
        scoring="neg_mean_absolute_error",
        n_jobs=1
    )

    importance_df = pd.DataFrame({
        "feature": X.columns,
        "importance_mean": result.importances_mean,
        "importance_std": result.importances_std
    }).sort_values(by="importance_mean", ascending=False)

    importance_df.to_csv(output_path, index=False, encoding="utf-8-sig")

    print(f"특징 중요도 파일 저장: {output_path}")
    print("\n상위 중요 특징 10개")
    print(importance_df.head(10).to_string(index=False))

    return importance_df


# =========================================================
# 6. 전력 반도체 후보 점수화
# =========================================================
def power_semiconductor_score(band_gap):
    """
    밴드갭만 기준으로 한 간단한 전력 반도체 후보 점수.
    실제 전력 반도체 적합성은 전자 이동도, 열전도도, 항복 전계, 결함, 제조 가능성도 함께 봐야 한다.

    점수 기준:
    - 2.5~5.5 eV: 와이드 밴드갭 전력 반도체 후보로 높은 점수
    - 1.0~2.5 eV: 일반 반도체 가능성은 있으나 고전압 전력용으로는 다소 낮음
    - 5.5~6.8 eV: 넓은 밴드갭 후보이나 절연체 성격이 강할 수 있음
    """
    if band_gap < 0.1:
        return 5, "금속에 가까움"

    if band_gap < 1.0:
        return 25, "밴드갭이 작아 전력 반도체 후보로는 약함"

    if band_gap < 2.5:
        score = 45 + (band_gap - 1.0) / 1.5 * 25
        return round(score, 1), "일반 반도체 후보"

    if band_gap <= 5.5:
        # GaN, SiC, Ga2O3 같은 전력 반도체 후보 범위를 높게 평가
        center = 3.6
        score = 100 - abs(band_gap - center) * 8
        score = max(75, min(100, score))
        return round(score, 1), "전력 반도체용 와이드 밴드갭 후보"

    if band_gap <= 6.8:
        score = 70 - (band_gap - 5.5) * 10
        return round(max(50, score), 1), "매우 넓은 밴드갭 후보, 절연체 성격 검토 필요"

    return 30, "절연체에 가까울 가능성 큼"


def uncertainty_label(std_value):
    if std_value < 0.3:
        return "낮음"
    if std_value < 0.8:
        return "보통"
    return "높음"


# =========================================================
# 7. 예측 함수
# =========================================================
def predict_formula(formula, model_package):
    feature_columns = model_package["feature_columns"]
    X_new = make_feature_table([formula])
    X_new = X_new.reindex(columns=feature_columns, fill_value=0)

    predictions = {}
    for model_name, model in model_package["models"].items():
        pred = float(model.predict(X_new)[0])
        predictions[model_name] = max(pred, 0.0)

    pred_values = np.array(list(predictions.values()))
    mean_gap = float(np.mean(pred_values))
    std_gap = float(np.std(pred_values))

    best_model_name = model_package["best_model_name"]
    best_gap = predictions[best_model_name]

    score, label = power_semiconductor_score(best_gap)
    mean_score, mean_label = power_semiconductor_score(mean_gap)

    return {
        "formula": formula,
        "predictions": predictions,
        "best_model_name": best_model_name,
        "best_gap": best_gap,
        "mean_gap": mean_gap,
        "std_gap": std_gap,
        "uncertainty": uncertainty_label(std_gap),
        "score": score,
        "label": label,
        "mean_score": mean_score,
        "mean_label": mean_label
    }


def print_prediction(result):
    print("\n예측 결과")
    print("=" * 80)
    print(f"입력 화학식: {result['formula']}")

    print("\n모델별 예측 밴드갭")
    for model_name, pred in result["predictions"].items():
        print(f"- {model_name:20s}: {pred:.3f} eV")

    print("\n최종 모델 기준")
    print(f"- 최종 선택 모델: {result['best_model_name']}")
    print(f"- 예측 밴드갭: {result['best_gap']:.3f} eV")
    print(f"- 전력 반도체 후보 점수: {result['score']}/100")
    print(f"- 판단: {result['label']}")

    print("\n3개 모델 평균 기준")
    print(f"- 평균 예측 밴드갭: {result['mean_gap']:.3f} eV")
    print(f"- 모델 간 표준편차: {result['std_gap']:.3f} eV")
    print(f"- 예측 불확실성: {result['uncertainty']}")
    print(f"- 평균 기준 판단: {result['mean_label']}")
    print("=" * 80)


# =========================================================
# 8. 후보 물질 순위화
# =========================================================
def rank_candidates(candidate_formulas, model_package, output_path="candidate_predictions.csv"):
    rows = []

    for formula in candidate_formulas:
        try:
            result = predict_formula(formula, model_package)
            row = {
                "formula": formula,
                "best_model": result["best_model_name"],
                "best_model_gap_eV": result["best_gap"],
                "three_model_mean_gap_eV": result["mean_gap"],
                "model_std_eV": result["std_gap"],
                "uncertainty": result["uncertainty"],
                "power_semiconductor_score": result["score"],
                "judgement": result["label"],
            }

            for model_name, pred in result["predictions"].items():
                row[f"{model_name}_gap_eV"] = pred

            rows.append(row)

        except Exception as error:
            rows.append({
                "formula": formula,
                "error": str(error)
            })

    ranking_df = pd.DataFrame(rows)

    if "power_semiconductor_score" in ranking_df.columns:
        ranking_df = ranking_df.sort_values(
            by=["power_semiconductor_score", "model_std_eV"],
            ascending=[False, True]
        )

    ranking_df.to_csv(output_path, index=False, encoding="utf-8-sig")
    print(f"\n후보 물질 순위 파일 저장: {output_path}")

    print("\n상위 후보 물질")
    columns_to_show = [
        "formula",
        "best_model_gap_eV",
        "three_model_mean_gap_eV",
        "model_std_eV",
        "power_semiconductor_score",
        "judgement"
    ]
    existing_columns = [col for col in columns_to_show if col in ranking_df.columns]
    print(ranking_df[existing_columns].head(15).to_string(index=False))

    return ranking_df


# =========================================================
# 9. 실행 설정 및 테스트
# =========================================================
DEFAULT_CANDIDATES = [
    "GaN", "SiC", "AlN", "Ga2O3", "ZnO", "BN", "InN", "GaP", "AlP", "ZnS",
    "ZnSe", "TiO2", "SnO2", "HfO2", "ZrO2", "BaTiO3", "SrTiO3", "In2O3",
    "WO3", "Ta2O5", "Nb2O5", "La2O3"
]


def read_candidates_file(path):
    """후보 화학식 txt 파일을 읽는다. 한 줄에 화학식 하나씩 작성하면 된다."""
    with open(path, "r", encoding="utf-8") as file:
        formulas = [line.strip() for line in file.readlines()]
    return [formula for formula in formulas if formula and not formula.startswith("#")]


def train_pipeline(data_path="bandgap_dataset.csv", fast=False):
    """데이터 불러오기 → 특징 생성 → 3개 모델 학습 → 결과 파일 저장."""
    df = load_data(data_path)

    print("\n데이터 개수:", len(df))
    print("데이터 미리보기")
    print(df.head().to_string(index=False))

    X = make_feature_table(df["formula"].tolist())
    y = df["band_gap"].astype(float)

    cv_splits = 5 if len(df) >= 50 else 3
    n_iter = 3 if fast else (12 if len(df) >= 50 else 5)

    models, results_df, best_model_name = tune_and_compare_models(
        X, y, cv_splits=cv_splits, n_iter=n_iter
    )

    results_df.to_csv("model_performance.csv", index=False, encoding="utf-8-sig")
    print("모델 성능 비교 파일 저장: model_performance.csv")

    model_package = {
        "models": models,
        "results": results_df,
        "best_model_name": best_model_name,
        "feature_columns": list(X.columns),
    }

    joblib.dump(model_package, "bandgap_competition_models.pkl")
    print("학습 모델 저장: bandgap_competition_models.pkl")

    analyze_feature_importance(
        models[best_model_name],
        X,
        y,
        output_path="feature_importance.csv"
    )

    return model_package


def run_tests():
    """기본 동작 확인용 테스트. VS Code 터미널에서 --run-tests로 실행."""
    print("자체 테스트 시작")

    assert parse_formula("GaN") == {"Ga": 1.0, "N": 1.0}
    assert parse_formula("Al2O3") == {"Al": 2.0, "O": 3.0}
    assert parse_formula("BaTiO3") == {"Ba": 1.0, "Ti": 1.0, "O": 3.0}

    try:
        parse_formula("XxO")
        raise AssertionError("지원하지 않는 원소 테스트 실패")
    except ValueError:
        pass

    features = formula_to_features("GaN")
    assert "en_range" in features
    assert "radius_mean" in features
    assert features["num_elements"] == 2

    score, label = power_semiconductor_score(3.4)
    assert score >= 75
    assert "전력 반도체" in label

    model_package = train_pipeline(fast=True)
    result = predict_formula("GaN", model_package)
    assert result["best_gap"] >= 0
    assert result["mean_gap"] >= 0
    assert result["uncertainty"] in ["낮음", "보통", "높음"]

    print("자체 테스트 통과")


def parse_args():
    parser = argparse.ArgumentParser(description="AI 기반 밴드갭 예측 프로그램")
    parser.add_argument("--data", default="bandgap_dataset.csv", help="학습 데이터 CSV 경로")
    parser.add_argument("--formulas", nargs="*", help="예측할 화학식 목록. 예: --formulas GaN SiC")
    parser.add_argument("--candidates", help="후보 화학식 txt 파일 경로. 한 줄에 하나씩 입력")
    parser.add_argument("--run-tests", action="store_true", help="자체 테스트 실행")
    parser.add_argument("--fast", action="store_true", help="빠른 실행용. 하이퍼파라미터 탐색 반복 수를 줄임")
    return parser.parse_args()


def main():
    args = parse_args()

    if args.run_tests:
        run_tests()
        return

    model_package = train_pipeline(data_path=args.data, fast=args.fast)

    if args.candidates:
        candidates = read_candidates_file(args.candidates)
    elif args.formulas:
        candidates = args.formulas
    else:
        candidates = DEFAULT_CANDIDATES

    rank_candidates(candidates, model_package, output_path="candidate_predictions.csv")

    print("\n개별 예측 결과")
    for formula in candidates:
        try:
            result = predict_formula(formula, model_package)
            print_prediction(result)
        except Exception as error:
            print(f"{formula} 예측 오류: {error}")

    print("\n실행 완료")
    print("생성 파일: model_performance.csv, feature_importance.csv, candidate_predictions.csv, bandgap_competition_models.pkl")


if __name__ == "__main__":
    main()
